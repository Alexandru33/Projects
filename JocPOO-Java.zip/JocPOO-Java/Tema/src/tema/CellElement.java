package tema;

public interface CellElement {
    char toCharacter();
}
