package tema;

public interface Potion {
    void foloseste(Character caracter);
    int getPret();
    int getGreutate();
    int valoareRegeneranta();

}
