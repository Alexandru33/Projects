package tema;

public class InvalidCommandException extends Exception{
    public InvalidCommandException()
    {
        super ("Comanda invalida");
    }
}
