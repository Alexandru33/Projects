package tema;

public class InformationIncompleteException extends Exception{

    public InformationIncompleteException()
    {
        super("InformationIncompleteException!!!");
    }
}
